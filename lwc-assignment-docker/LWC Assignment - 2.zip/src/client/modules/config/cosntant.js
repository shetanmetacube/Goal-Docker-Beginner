export default  {
    SERVER_URL : "http://localhost:3002"
}